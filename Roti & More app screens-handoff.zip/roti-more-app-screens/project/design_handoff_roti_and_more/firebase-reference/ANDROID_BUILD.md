# Build the Android app (APK / AAB) for the Play Store

Your project already includes Capacitor and an `android/` folder, so you can
wrap the finished web app into a real Android app. You need **Android Studio**
(free) for this step — it's the one tool that has to run on a computer
(Windows/Mac/Linux). If you can't install it, see "No-computer options" at the
end.

## Prerequisites
- Node.js installed (to build the web app).
- **Android Studio** — https://developer.android.com/studio
- The app working in the browser first (`npm run dev`).

## 1. Build the web app
```
cd roti-and-more-app
npm install
npm run build          # creates the dist/ folder
```

## 2. Sync into the Android project
```
npx cap sync android
```
This copies your built web app into `android/` and updates plugins.

## 3. Open in Android Studio
```
npx cap open android
```
Android Studio launches with the project. Let it finish "Gradle sync" (bottom
status bar) the first time — it downloads dependencies.

## 4. App identity (do once)
- App name / package id live in `capacitor.config.ts` (`appId` like
  `com.rotiandmore.app`, `appName` "Roti & More"). Set these before building.
- App icon: replace the icons under `android/app/src/main/res/mipmap-*` (or use
  Android Studio → right-click `res` → New → Image Asset).

## 5. Test it
- Plug in an Android phone (enable USB debugging) **or** use an emulator
  (Android Studio → Device Manager → create a virtual device).
- Press the green **Run ▶** button. The app installs and launches.

## 6. Make a signed release (required for Play Store)
1. Android Studio → **Build → Generate Signed Bundle / APK**.
2. Choose **Android App Bundle (.aab)** — this is what Google Play wants.
   (Choose **APK** only if you want a file to share/sideload directly.)
3. **Create new keystore** (first time): pick a file location, set a password,
   fill the name fields. **Back up this keystore file + passwords forever** —
   you cannot update the app later without it.
4. Build variant: **release**. Finish.
5. The `.aab` (or `.apk`) is written to
   `android/app/release/`. Android Studio shows a "locate" link.

## 7. Publish on Google Play
1. Create a **Google Play Console** account (one-time US$25):
   https://play.google.com/console
2. **Create app** → fill the store listing (name, short/long description,
   screenshots — you can screenshot the running app, category "Food & Drink",
   privacy policy URL).
3. **Production → Create new release** → upload the **.aab**.
4. Complete the content rating, data-safety, and target-audience questionnaires.
5. Submit for review. First review typically takes a few days.

## Updating later
Change code → `npm run build` → `npx cap sync android` → bump
`versionCode`/`versionName` in `android/app/build.gradle` → generate a new
signed `.aab` (same keystore) → upload a new release.

## Notes
- **Phone OTP on device:** Firebase Phone Auth works in the Android app. Add
  your app's **SHA-1/SHA-256** fingerprints in Firebase console → Project
  settings → your Android app, so real SMS/verification works on device.
  (Android Studio → Gradle → signingReport shows the fingerprints.)
- **APK vs AAB:** Play Store needs `.aab`. Use `.apk` only for direct install
  outside the store.

## No-computer options
Android Studio needs a desktop. If you don't have one:
- Ask a developer to do steps 1–6 once with these files (an hour or two).
- Or ship it as an **installable website (PWA)** first — your project already
  has `manifest.json` + a service worker, so once the site is hosted, users can
  "Add to Home screen" and it behaves like an app while you arrange the Play
  Store build.
