// src/firebase/actions.ts — call the Cloud Functions backend from the app.
// Use these INSTEAD of the write functions in data.ts once Functions are
// deployed. Reads (listOrders/listProducts/listNotifications/listCustomers)
// still come from data.ts — those are fine directly from Firestore.
import { getFunctions, httpsCallable } from "firebase/functions";
import { app } from "./config";

const fns = getFunctions(app);
const call = (name: string) => httpsCallable(fns, name);

export const actions = {
  placeOrder: (cart: { productId: string; quantity: number }[], deliveryDate: string, deliveryTime: string, remarks?: string) =>
    call("placeOrder")({ cart, deliveryDate, deliveryTime, remarks }),
  acceptOrder: (id: string) => call("acceptOrder")({ id }),
  rejectOrder: (id: string) => call("rejectOrder")({ id }),
  deliverOrder: (id: string) => call("deliverOrder")({ id }),
  addPayment: (id: string, amount: number, note?: string, mode?: string, transactionId?: string) =>
    call("addPayment")({ id, amount, note, mode, transactionId }),
  cancelOrder: (id: string) => call("cancelOrder")({ id }),
  reschedule: (id: string, deliveryDate: string, deliveryTime: string) =>
    call("reschedule")({ id, deliveryDate, deliveryTime }),
  editAddress: (id: string, address: string) => call("editAddress")({ id, address }),
};

// Errors from the backend arrive as { code, message }. Show err.message to the
// user (e.g. "Cancellation window has closed (6 hours)").
