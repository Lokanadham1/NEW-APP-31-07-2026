// src/firebase/live.ts — real-time listeners (FREE on the Spark plan).
// Screens auto-update when data changes, no manual refresh. Each function
// returns an unsubscribe() — call it in a useEffect cleanup.
import { collection, onSnapshot, query, where, orderBy } from "firebase/firestore";
import { db } from "./config";

const snapList = (s: any) => s.docs.map((d: any) => ({ id: d.id, ...d.data() }));

// Orders — admin sees all, customer sees their own. Live.
export function watchOrders(role: "user" | "admin", uid: string, cb: (orders: any[]) => void) {
  const col = collection(db, "orders");
  const q = role === "admin"
    ? query(col, orderBy("createdAt", "desc"))
    : query(col, where("userId", "==", uid), orderBy("createdAt", "desc"));
  return onSnapshot(q, (s) => cb(snapList(s)));
}

// Products — live.
export function watchProducts(cb: (products: any[]) => void) {
  return onSnapshot(collection(db, "products"), (s) => cb(snapList(s)));
}

// Notifications for this audience ("admin" or the customer uid) — live.
export function watchNotifications(role: "user" | "admin", uid: string, cb: (n: any[]) => void) {
  const audience = role === "admin" ? "admin" : uid;
  const q = query(collection(db, "notifications"), where("userId", "==", audience), orderBy("createdAt", "desc"));
  return onSnapshot(q, (s) => cb(snapList(s)));
}

/*  Usage in App.tsx (replaces the manual reload()):

    useEffect(() => {
      if (!me) return;
      const unsubs = [
        watchOrders(me.role, me.uid, setOrders),
        watchProducts(setProducts),
        watchNotifications(me.role, me.uid, setNotifications),
      ];
      return () => unsubs.forEach((u) => u());
    }, [me]);

    Now the admin sees new orders instantly and customers see status/payment
    changes live — with no Blaze plan and no extra cost.
*/
