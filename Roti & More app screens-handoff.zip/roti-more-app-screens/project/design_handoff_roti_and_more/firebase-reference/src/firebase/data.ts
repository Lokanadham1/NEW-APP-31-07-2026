// src/firebase/data.ts — all Firestore reads/writes. Replaces the Node API
// client. Business logic (totals, payment/status) runs here, in the app.
import {
  collection, doc, getDoc, getDocs, setDoc, updateDoc, deleteDoc, addDoc,
  query, where, orderBy, serverTimestamp,
} from "firebase/firestore";
import { db, auth } from "./config";

export type Product = { id: string; name: string; price: number; description: string; category: string; status: "available" | "out_of_stock"; imageUrl?: string };
export type OrderItem = { productId: string; name: string; price: number; quantity: number };
export type Payment = { amount: number; date: string; note: string; mode: string; transactionId: string };
export type Order = {
  id: string; userId: string; customerName: string; customerMobile: string; customerAddress: string;
  items: OrderItem[]; subtotal: number; total: number;
  status: "pending" | "approved" | "completed" | "rejected" | "cancelled";
  createdDate: string; deliveryDate: string | null; deliveryTime: string | null;
  remarks: string | null; contactPerson: string | null;
  paidAmount: number; payments: Payment[]; addressEditUsed: boolean; rescheduleUsed: boolean;
};

const today = () => new Date().toISOString().split("T")[0];
const snapData = <T,>(s: any): T => ({ id: s.id, ...s.data() });

async function notify(userId: string, message: string) {
  await addDoc(collection(db, "notifications"), {
    userId, message, read: false, createdDate: today(), createdAt: serverTimestamp(),
  });
}

// ── Products ────────────────────────────────────────────────────────────────
export async function listProducts(): Promise<Product[]> {
  const snap = await getDocs(collection(db, "products"));
  return snap.docs.map((d) => snapData<Product>(d));
}
export async function createProduct(p: Omit<Product, "id">) {
  const ref = await addDoc(collection(db, "products"), p);
  return { id: ref.id, ...p };
}
export async function updateProduct(id: string, p: Partial<Product>) {
  await updateDoc(doc(db, "products", id), p as any);
}
export async function deleteProduct(id: string) {
  await deleteDoc(doc(db, "products", id));
}

// ── Orders ────────────────────────────────────────────────────────────────
export async function listOrders(role: "user" | "admin", uid: string, status?: string): Promise<Order[]> {
  const col = collection(db, "orders");
  let q;
  if (role === "admin") q = query(col, orderBy("createdAt", "desc"));
  else q = query(col, where("userId", "==", uid), orderBy("createdAt", "desc"));
  const snap = await getDocs(q);
  let out = snap.docs.map((d) => snapData<Order>(d));
  if (status && status !== "all") out = out.filter((o) => o.status === status);
  return out;
}

export async function createOrder(input: {
  cart: { productId: string; quantity: number }[];
  deliveryDate: string; deliveryTime: string; remarks?: string;
}) {
  const u = auth.currentUser!;
  const me = (await getDoc(doc(db, "users", u.uid))).data() as any;
  const products = await listProducts();
  const items: OrderItem[] = input.cart.map((c) => {
    const p = products.find((x) => x.id === c.productId)!;
    return { productId: p.id, name: p.name, price: p.price, quantity: c.quantity };
  });
  const subtotal = items.reduce((s, i) => s + i.price * i.quantity, 0);
  const id = String(Math.floor(1000 + Math.random() * 9000));
  const displayName = me.cateringName || me.name;
  const order: Order & { createdAt: any } = {
    id, userId: u.uid, customerName: displayName, customerMobile: me.mobile,
    customerAddress: me.address, items, subtotal, total: subtotal, status: "pending",
    createdDate: today(), deliveryDate: input.deliveryDate, deliveryTime: input.deliveryTime,
    remarks: input.remarks || null, contactPerson: me.name, paidAmount: 0, payments: [],
    addressEditUsed: false, rescheduleUsed: false, createdAt: serverTimestamp(),
  };
  await setDoc(doc(db, "orders", id), order);
  await notify("admin", `New Order #${id} from ${displayName} (${me.mobile}) — ₹${subtotal} | Delivery: ${input.deliveryDate} at ${input.deliveryTime}`);
  return order;
}

const setStatus = (id: string, status: Order["status"]) => updateDoc(doc(db, "orders", id), { status });

export async function acceptOrder(o: Order) {
  await setStatus(o.id, "approved");
  await notify(o.userId, `🟢 Order #${o.id} accepted! Delivery: ${o.deliveryDate} at ${o.deliveryTime}. Total: ₹${o.total}`);
}
export async function rejectOrder(o: Order) {
  await setStatus(o.id, "rejected");
  await notify(o.userId, `🔴 Order #${o.id} could not be accepted. Please contact us.`);
}
export async function deliverOrder(o: Order) {
  await setStatus(o.id, "completed");
  await notify(o.userId, `📦 Order #${o.id} marked delivered.`);
}

// customer cancel — only pending & within 6 hours (also enforced-ish in rules)
export function canCancel(o: Order & { createdAt?: any }) {
  if (o.status !== "pending") return false;
  const t = o.createdAt?.toDate ? o.createdAt.toDate().getTime() : Date.now();
  return Date.now() - t < 6 * 3600 * 1000;
}
export async function cancelOrder(o: Order) {
  await setStatus(o.id, "cancelled");
  await notify("admin", `🚫 Order #${o.id} was cancelled by customer.`);
}

export async function reschedule(o: Order, deliveryDate: string, deliveryTime: string, byAdmin: boolean) {
  await updateDoc(doc(db, "orders", o.id), {
    deliveryDate, deliveryTime, rescheduleUsed: byAdmin ? o.rescheduleUsed : true,
  });
  await notify(byAdmin ? o.userId : "admin",
    `${byAdmin ? "⏰ Delivery rescheduled for" : "📅 Customer rescheduled"} #${o.id}: ${deliveryDate} at ${deliveryTime}`);
}

export async function editAddress(o: Order, address: string) {
  await updateDoc(doc(db, "orders", o.id), { customerAddress: address, addressEditUsed: true });
  await notify("admin", `📍 Customer updated delivery address for Order #${o.id}: ${address}`);
}

export async function addPayment(o: Order, p: { amount: number; note?: string; mode?: string; transactionId?: string }) {
  const payments = [...o.payments, {
    amount: p.amount, date: today(), note: p.note || "Payment received",
    mode: p.mode || "Cash", transactionId: p.transactionId || "",
  }];
  const paidAmount = o.paidAmount + p.amount;
  const status = paidAmount >= o.total ? "completed" : o.status;
  await updateDoc(doc(db, "orders", o.id), { payments, paidAmount, status });
  const bal = o.total - paidAmount;
  await notify(o.userId, bal <= 0
    ? `✅ Order #${o.id} fully paid. Thank you!`
    : `💰 Payment of ₹${p.amount} for order #${o.id}. Balance: ₹${bal}`);
}

// ── Customers (admin) ────────────────────────────────────────────────────────
export async function listCustomers() {
  const [usersSnap, ordersSnap] = await Promise.all([
    getDocs(query(collection(db, "users"), where("role", "==", "user"))),
    getDocs(collection(db, "orders")),
  ]);
  const orders = ordersSnap.docs.map((d) => snapData<Order>(d));
  return usersSnap.docs.map((d) => {
    const u: any = { uid: d.id, ...d.data() };
    const mine = orders.filter((o) => o.userId === u.uid);
    const totalPurchase = mine.reduce((s, o) => s + o.total, 0);
    const totalPaid = mine.reduce((s, o) => s + o.paidAmount, 0);
    return {
      userId: u.uid, customerId: u.customerId, name: u.cateringName || u.name || "—",
      mobile: u.mobile, address: u.address, orders: mine,
      orderCount: mine.length, totalPurchase, totalPaid, pending: totalPurchase - totalPaid,
    };
  }).sort((a, b) => (a.customerId || "").localeCompare(b.customerId || ""));
}

// ── Notifications ────────────────────────────────────────────────────────────
export async function listNotifications(role: "user" | "admin", uid: string) {
  const audience = role === "admin" ? "admin" : uid;
  const snap = await getDocs(query(collection(db, "notifications"), where("userId", "==", audience), orderBy("createdAt", "desc")));
  return snap.docs.map((d) => snapData<any>(d));
}
export const markRead = (id: string) => updateDoc(doc(db, "notifications", id), { read: true });
