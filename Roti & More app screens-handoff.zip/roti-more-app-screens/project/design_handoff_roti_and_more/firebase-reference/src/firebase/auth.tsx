// src/firebase/auth.tsx — auth state via Firebase Phone Auth.
// Determines admin role by checking the /admins/{phone} allowlist, ensures a
// /users/{uid} profile doc exists, and exposes { ready, me, role } to the app.
import { createContext, useContext, useEffect, useState, ReactNode } from "react";
import { onAuthStateChanged, signOut } from "firebase/auth";
import { doc, getDoc, setDoc } from "firebase/firestore";
import { auth, db } from "./config";

export type Role = "user" | "admin";
export type Me = {
  uid: string; mobile: string; customerId: string | null; role: Role;
  name?: string; cateringName?: string; address?: string; profileDone: boolean;
};

type AuthState = {
  ready: boolean; me: Me | null; role: Role | null; isAuthed: boolean;
  refresh: () => Promise<void>; logout: () => Promise<void>;
};

const Ctx = createContext<AuthState>(null as any);
export const useAuth = () => useContext(Ctx);

// next CUSxxxx id — reads a counter doc so ids are sequential
async function nextCustomerId(): Promise<string> {
  const ref = doc(db, "meta", "custCounter");
  const snap = await getDoc(ref);
  const n = snap.exists() ? (snap.data().value as number) : 1;
  await setDoc(ref, { value: n + 1 });
  return "CUS" + String(n).padStart(4, "0");
}

// Ensure a users/{uid} doc exists; set role from the admins allowlist.
async function ensureUser(uid: string, phoneE164: string): Promise<Me> {
  const mobile = phoneE164.replace(/^\+91/, "").replace(/^\+/, "");
  const isAdmin = (await getDoc(doc(db, "admins", phoneE164))).exists();
  const ref = doc(db, "users", uid);
  const snap = await getDoc(ref);

  if (!snap.exists()) {
    const base: any = {
      mobile, role: isAdmin ? "admin" : "user",
      customerId: isAdmin ? null : await nextCustomerId(),
      name: "", cateringName: "", address: "",
      profileDone: isAdmin,   // admins skip profile setup
    };
    await setDoc(ref, base);
    return { uid, ...base } as Me;
  }
  const data = snap.data() as any;
  // keep role in sync if allowlist changed
  const role: Role = isAdmin ? "admin" : "user";
  if (data.role !== role) { await setDoc(ref, { role }, { merge: true }); data.role = role; }
  return { uid, ...data } as Me;
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [me, setMe] = useState<Me | null>(null);
  const [ready, setReady] = useState(false);

  useEffect(() => onAuthStateChanged(auth, async (u) => {
    if (u && u.phoneNumber) setMe(await ensureUser(u.uid, u.phoneNumber));
    else setMe(null);
    setReady(true);
  }), []);

  const refresh = async () => {
    const u = auth.currentUser;
    if (u && u.phoneNumber) setMe(await ensureUser(u.uid, u.phoneNumber));
  };
  const logout = async () => { await signOut(auth); setMe(null); };

  return (
    <Ctx.Provider value={{ ready, me, role: me?.role ?? null, isAuthed: !!me, refresh, logout }}>
      {children}
    </Ctx.Provider>
  );
}

export function landingView(me: Me | null): string {
  if (!me) return "login";
  if (me.role === "admin") return "admin-dashboard";
  if (!me.profileDone) return "profile-setup";
  return "user-home";
}
