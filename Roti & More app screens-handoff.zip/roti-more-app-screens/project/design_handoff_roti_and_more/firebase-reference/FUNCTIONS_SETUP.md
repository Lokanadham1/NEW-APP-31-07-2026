# Cloud Functions backend (the real server-side backend)

This is the proper backend for the Firebase app: trusted code that runs on
Google's servers. The app **asks** these functions to do things; it can't skip
their checks (totals recomputed server-side, payment can't exceed balance, the
6-hour cancel window, once-only reschedule/address, admin-only actions).

Use this if you want stronger guarantees than the in-app `data.ts` logic. It's
optional — `data.ts` + security rules already work for a small trusted setup.

## Requirements
- The **Blaze (pay-as-you-go)** plan on your Firebase project. Cloud Functions
  need it. At your volume it's effectively free (generous free tier), but a card
  is required. Set a budget alert to stay safe.
- The **Firebase CLI** on a computer: `npm install -g firebase-tools`.

## One-time setup
```
cd firebase-app            # (or your project root)
firebase login             # opens a browser
firebase init functions    # pick your project; choose JavaScript; DON'T overwrite
                           # the existing functions/ files when asked
cd functions
npm install
```
(If you copy the provided `functions/` folder into a project you already
`firebase init`'d, just run `npm install` inside it.)

## Deploy
```
firebase deploy --only functions
```
This publishes: placeOrder, acceptOrder, rejectOrder, deliverOrder, addPayment,
cancelOrder, reschedule, editAddress, and the onOrderCreated trigger.

## Point the app at the functions
1. Copy `src/firebase/actions.ts` into `roti-and-more-app/src/firebase/`.
2. In `App.tsx`, replace the `data.*` WRITE calls with `actions.*`
   (see the mapping in APP_INTEGRATION.md — same idea, just swap the source):
   ```ts
   // before:  await data.acceptOrder(order); await reload();
   // after:   await actions.acceptOrder(order.id); await reload();
   ```
   Keep using `data.listOrders / listProducts / listNotifications /
   listCustomers` for READS.
3. Errors: wrap calls in try/catch and show `err.message` — the backend returns
   friendly messages like "Amount exceeds remaining balance".

## What stays where
| Concern | Lives in |
|---|---|
| Reads (lists) | `data.ts` (direct Firestore) |
| Trusted writes (orders, payments, status) | **Cloud Functions** (`functions/index.js`) |
| Who-can-read-what guardrails | `firestore.rules` |
| Login / admin detection | `auth.tsx` + `admins/` collection |

## Local testing (optional)
```
firebase emulators:start --only functions,firestore
```
lets you run the functions on your machine before deploying.

## Push notifications (optional next step)
`onOrderCreated` is a stub where you can send a push/SMS/email to the admin
when an order arrives. Wire Firebase Cloud Messaging (FCM) there later.
