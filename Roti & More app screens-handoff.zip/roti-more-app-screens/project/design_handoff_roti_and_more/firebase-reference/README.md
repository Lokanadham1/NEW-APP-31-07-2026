# Roti & More — Firebase-only build (no server)

Everything here lets you run the app with **only Firebase** (no Node backend)
and publish it as an **Android app**. Follow the guides in this order:

1. **FIREBASE_SETUP.md** — set up Firebase in the browser (project, phone login,
   database, admin number, security rules).
2. **APP_INTEGRATION.md** — copy the 4 code files into your app and connect
   `App.tsx` to Firebase.
3. **ANDROID_BUILD.md** — build the APK/AAB in Android Studio and publish to the
   Play Store.

Reference:
- **firestore.rules** — paste into Firebase → Firestore → Rules.
- **firestore-structure.md** — what the database looks like.
- **FUNCTIONS_SETUP.md** + **functions/** — OPTIONAL real server-side backend
  (Cloud Functions) for trusted order/payment logic. Use if you want stronger
  guarantees than the in-app `data.ts` logic.

Code files (copy into `roti-and-more-app/src/`):
- `src/firebase/config.ts` — Firebase connection
- `src/firebase/auth.tsx` — phone login + admin-by-number
- `src/firebase/data.ts` — all database reads/writes (replaces the server)
- `src/app/LoginFlow.tsx` — the login/OTP/profile screen

## Which to use — Firebase-only vs the Node backend?
This folder (`firebase-app/`) is the **Firebase-only** path — simplest to run,
nothing to host yourself. The `backend/` + `frontend-wiring/` folders are the
alternative **own-server** path. **Pick one.** For a solo owner shipping to the
Play Store, use this Firebase-only version and you can ignore `backend/`.
