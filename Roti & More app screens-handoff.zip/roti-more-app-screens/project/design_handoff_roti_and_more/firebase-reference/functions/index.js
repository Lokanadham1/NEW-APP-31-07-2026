// functions/index.js — the REAL backend: trusted logic that runs on Google's
// servers, not in the app. The app calls these with httpsCallable; the app
// cannot be tricked into skipping the rules here.
//
// Deploy:  firebase deploy --only functions   (needs the Blaze plan)
const { onCall, HttpsError } = require("firebase-functions/v2/https");
const { onDocumentCreated } = require("firebase-functions/v2/firestore");
const admin = require("firebase-admin");

admin.initializeApp();
const db = admin.firestore();

const today = () => new Date().toISOString().split("T")[0];

// ── helpers ──────────────────────────────────────────────────────────────────
function requireAuth(req) {
  if (!req.auth) throw new HttpsError("unauthenticated", "Sign in first.");
  return req.auth;
}
async function isAdmin(auth) {
  const phone = auth.token.phone_number;
  if (!phone) return false;
  return (await db.doc(`admins/${phone}`).get()).exists;
}
async function requireAdmin(req) {
  const auth = requireAuth(req);
  if (!(await isAdmin(auth))) throw new HttpsError("permission-denied", "Admin only.");
  return auth;
}
async function getOrder(id) {
  const snap = await db.doc(`orders/${id}`).get();
  if (!snap.exists) throw new HttpsError("not-found", "Order not found.");
  return { ref: snap.ref, data: snap.data() };
}
async function notify(userId, message) {
  await db.collection("notifications").add({
    userId, message, read: false, createdDate: today(),
    createdAt: admin.firestore.FieldValue.serverTimestamp(),
  });
}

// ── place order (customer) — totals recomputed from live product prices ──────
exports.placeOrder = onCall(async (req) => {
  const auth = requireAuth(req);
  const { cart, deliveryDate, deliveryTime, remarks } = req.data || {};
  if (!Array.isArray(cart) || cart.length === 0) throw new HttpsError("invalid-argument", "Cart is empty.");
  if (!deliveryDate || !deliveryTime) throw new HttpsError("invalid-argument", "Select delivery date and time.");

  const me = (await db.doc(`users/${auth.uid}`).get()).data();
  if (!me || !me.profileDone) throw new HttpsError("failed-precondition", "Complete your profile first.");

  const items = [];
  for (const c of cart) {
    const p = (await db.doc(`products/${c.productId}`).get()).data();
    if (!p) throw new HttpsError("not-found", "Unknown product " + c.productId);
    items.push({ productId: c.productId, name: p.name, price: p.price, quantity: Math.max(1, +c.quantity) });
  }
  const subtotal = items.reduce((s, i) => s + i.price * i.quantity, 0);
  const id = String(Math.floor(1000 + Math.random() * 9000));
  const displayName = me.cateringName || me.name;

  await db.doc(`orders/${id}`).set({
    userId: auth.uid, customerName: displayName, customerMobile: me.mobile,
    customerAddress: me.address, items, subtotal, total: subtotal, status: "pending",
    createdDate: today(), createdAt: admin.firestore.FieldValue.serverTimestamp(),
    deliveryDate, deliveryTime, remarks: remarks || null, contactPerson: me.name,
    paidAmount: 0, payments: [], addressEditUsed: false, rescheduleUsed: false,
  });
  await notify("admin", `New Order #${id} from ${displayName} (${me.mobile}) — ₹${subtotal} | Delivery: ${deliveryDate} at ${deliveryTime}`);
  return { id };
});

// ── admin: accept / reject / deliver ─────────────────────────────────────────
exports.acceptOrder = onCall(async (req) => {
  await requireAdmin(req);
  const { ref, data } = await getOrder(req.data.id);
  if (data.status !== "pending") throw new HttpsError("failed-precondition", "Only pending orders can be accepted.");
  await ref.update({ status: "approved" });
  await notify(data.userId, `🟢 Order #${req.data.id} accepted! Delivery: ${data.deliveryDate} at ${data.deliveryTime}. Total: ₹${data.total}`);
  return { ok: true };
});

exports.rejectOrder = onCall(async (req) => {
  await requireAdmin(req);
  const { ref, data } = await getOrder(req.data.id);
  await ref.update({ status: "rejected" });
  await notify(data.userId, `🔴 Order #${req.data.id} could not be accepted. Please contact us.`);
  return { ok: true };
});

exports.deliverOrder = onCall(async (req) => {
  await requireAdmin(req);
  const { ref, data } = await getOrder(req.data.id);
  await ref.update({ status: "completed" });
  await notify(data.userId, `📦 Order #${req.data.id} marked delivered.`);
  return { ok: true };
});

// ── admin: record payment — clamps to balance, auto-completes ────────────────
exports.addPayment = onCall(async (req) => {
  await requireAdmin(req);
  const { id, amount, note, mode, transactionId } = req.data || {};
  const { ref, data } = await getOrder(id);
  const amt = Number(amount);
  const remaining = data.total - data.paidAmount;
  if (!amt || amt <= 0) throw new HttpsError("invalid-argument", "Enter a valid amount.");
  if (amt > remaining) throw new HttpsError("invalid-argument", `Amount exceeds remaining balance (₹${remaining}).`);

  const payments = [...(data.payments || []), {
    amount: amt, date: today(), note: note || "Payment received",
    mode: mode || "Cash", transactionId: transactionId || "",
  }];
  const paidAmount = data.paidAmount + amt;
  const status = paidAmount >= data.total ? "completed" : data.status;
  await ref.update({ payments, paidAmount, status });
  const bal = data.total - paidAmount;
  await notify(data.userId, bal <= 0
    ? `✅ Order #${id} fully paid. Thank you!`
    : `💰 Payment of ₹${amt} for order #${id}. Balance: ₹${bal}`);
  return { ok: true, paidAmount, status };
});

// ── customer: cancel (pending & within 6h) ───────────────────────────────────
exports.cancelOrder = onCall(async (req) => {
  const auth = requireAuth(req);
  const { ref, data } = await getOrder(req.data.id);
  const admin_ = await isAdmin(auth);
  if (!admin_ && data.userId !== auth.uid) throw new HttpsError("permission-denied", "Not your order.");
  if (!admin_) {
    if (data.status !== "pending") throw new HttpsError("failed-precondition", "Only pending orders can be cancelled.");
    const created = data.createdAt?.toDate ? data.createdAt.toDate().getTime() : Date.now();
    if (Date.now() - created >= 6 * 3600 * 1000) throw new HttpsError("failed-precondition", "Cancellation window has closed (6 hours).");
  }
  await ref.update({ status: "cancelled" });
  await notify("admin", `🚫 Order #${req.data.id} was cancelled by customer.`);
  return { ok: true };
});

// ── reschedule (customer once, admin any time) ────────────────────────────────
exports.reschedule = onCall(async (req) => {
  const auth = requireAuth(req);
  const { id, deliveryDate, deliveryTime } = req.data || {};
  if (!deliveryDate || !deliveryTime) throw new HttpsError("invalid-argument", "Date and time required.");
  const { ref, data } = await getOrder(id);
  const admin_ = await isAdmin(auth);
  if (!admin_) {
    if (data.userId !== auth.uid) throw new HttpsError("permission-denied", "Not your order.");
    if (data.rescheduleUsed) throw new HttpsError("failed-precondition", "You can reschedule only once.");
  }
  await ref.update({ deliveryDate, deliveryTime, rescheduleUsed: admin_ ? !!data.rescheduleUsed : true });
  await notify(admin_ ? data.userId : "admin",
    `${admin_ ? "⏰ Delivery rescheduled for" : "📅 Customer rescheduled"} #${id}: ${deliveryDate} at ${deliveryTime}`);
  return { ok: true };
});

// ── customer: edit address once ───────────────────────────────────────────────
exports.editAddress = onCall(async (req) => {
  const auth = requireAuth(req);
  const { id, address } = req.data || {};
  if (!address || !address.trim()) throw new HttpsError("invalid-argument", "Address required.");
  const { ref, data } = await getOrder(id);
  if (data.userId !== auth.uid) throw new HttpsError("permission-denied", "Not your order.");
  if (data.addressEditUsed) throw new HttpsError("failed-precondition", "Address can be edited only once.");
  await ref.update({ customerAddress: address.trim(), addressEditUsed: true });
  await notify("admin", `📍 Customer updated delivery address for Order #${id}: ${address.trim()}`);
  return { ok: true };
});

// ── optional: toast admins in real time when an order arrives ─────────────────
exports.onOrderCreated = onDocumentCreated("orders/{id}", async (event) => {
  // Hook point for push/email/SMS to the admin. Left as a no-op stub.
  // e.g. send FCM to admin devices here.
  return;
});
