# Firestore data structure — Roti & More

Firebase Firestore is a "collection of documents" database. Here are the
collections the app uses. You don't create these by hand (except `admins` and
seeding `products`) — the app writes them as people use it.

## `admins/{phoneNumber}`
The admin allowlist. Document **id is the full phone number** in +91 form.
Create these by hand in the Firebase console. Content can be empty `{}`.
```
admins/+919876543210   {}      ← this number logs in as admin
```

## `products/{autoId}`
```
name:        "Poli"
price:       30
description: "Sweet lentil stuffed flatbread"
category:    "Flatbreads"
status:      "available" | "out_of_stock"
imageUrl:    "https://…"   (optional, from Firebase Storage)
```

## `users/{uid}`
One per logged-in person (uid comes from Firebase Auth).
```
mobile:       "9876543210"
customerId:   "CUS0001"        (customers only)
role:         "user" | "admin"
name:         "Ramesh"
cateringName: "Ramesh Catering"
address:      "12, MG Road, Hyderabad"
profileDone:  true
```

## `orders/{orderId}`
`orderId` is a 4-digit string like "1054".
```
userId:          "<uid of customer>"
customerName:    "Ramesh Catering"
customerMobile:  "9876543210"
customerAddress: "12, MG Road, Hyderabad"
items:           [ { productId, name, price, quantity } ]
subtotal:        500
total:           500
status:          "pending" | "approved" | "completed" | "rejected" | "cancelled"
createdDate:     "2026-07-18"
createdAt:       <timestamp>
deliveryDate:    "2026-07-24"
deliveryTime:    "10:00"
remarks:         null
contactPerson:   "Ramesh"
paidAmount:      0
payments:        [ { amount, date, note, mode, transactionId } ]
addressEditUsed: false
rescheduleUsed:  false
```

## `notifications/{autoId}`
```
userId:      "<uid>"  for a customer  ·  "admin"  for admin broadcasts
message:     "New Order #1054 …"
read:        false
createdDate: "2026-07-18"
createdAt:   <timestamp>
```

## Notes
- With Firebase-only (no server), the app calculates order totals and applies
  the payment/status logic in the app code. Security rules stop customers from
  editing money or approving their own orders, but the exact 6-hour cancel
  window is enforced in the app. For stricter server-side enforcement later you
  can add **Cloud Functions** (needs the Blaze plan) — optional.
