# Connecting App.tsx to Firebase (no server)

After copying the four files and running `npm install firebase`, make these
edits to your existing `roti-and-more-app`.

## 1. Wrap the app
`src/main.tsx`:
```tsx
import { AuthProvider } from "./firebase/auth";
root.render(<AuthProvider><App /></AuthProvider>);
```

## 2. Boot on auth (top of App())
Remove the old `ls(...)` initial state for `currentUser`/`isAdmin`/`view` and
the localStorage-persist effects. Add:
```tsx
import { useAuth, landingView } from "../firebase/auth";
import * as data from "../firebase/data";
import LoginFlow from "./LoginFlow";

const { ready, me, role, logout } = useAuth();
const [view, setView] = useState("splash");
const [orders, setOrders] = useState<data.Order[]>([]);
const [products, setProducts] = useState<data.Product[]>([]);
const [notifications, setNotifications] = useState<any[]>([]);

useEffect(() => {
  if (!ready) return;
  setView(landingView(me));
  if (me) reload();
}, [ready, me]);

async function reload() {
  if (!me) return;
  const [o, p, n] = await Promise.all([
    data.listOrders(me.role, me.uid),
    data.listProducts(),
    data.listNotifications(me.role, me.uid),
  ]);
  setOrders(o); setProducts(p); setNotifications(n);
}
```

## 3. Show login
Before the view switch:
```tsx
if (!ready) return <div className="min-h-screen bg-primary" />; // brief splash
if (!me) return <LoginFlow onDone={() => reload()} />;
```
Delete the old `splash`, `user-login`, `admin-login` views and their handlers
(`submitUserLogin`, `submitAdminLogin`) and the login form state.

## 4. Swap handlers (keep the UI, change the action)
| Old | New (await, then update state or `reload()`) |
|---|---|
| place order | `await data.createOrder({ cart: selectedItems.map(p=>({productId:p.id, quantity:productQty[p.id]})), deliveryDate: checkoutDate, deliveryTime: checkoutTime, remarks: checkoutNotes }); setProductQty({}); await reload(); setView("user-orders");` |
| cancel | `await data.cancelOrder(order); await reload();` |
| customer reschedule | `await data.reschedule(order, userRescheduleDate, userRescheduleTime, false); await reload();` |
| admin reschedule | `await data.reschedule(order, newDeliveryDate, newDeliveryTime, true); await reload();` |
| edit address | `await data.editAddress(order, addressEditValue); await reload();` |
| add payment | `await data.addPayment(paymentOrder, { amount:Number(paymentAmount), note:paymentNote, mode:paymentMode, transactionId:paymentTxId }); await reload();` |
| accept | `await data.acceptOrder(acceptOrder); await reload();` |
| reject | `await data.rejectOrder(order); await reload();` |
| mark delivered | `await data.deliverOrder(order); await reload();` |
| save product | `editingProduct ? await data.updateProduct(editingProduct.id, {...}) : await data.createProduct({...}); await reload();` |
| delete product | `await data.deleteProduct(id); await reload();` |
| mark notif read | `await data.markRead(id); await reload();` |
| logout | `await logout(); setView("login");` |

Notes:
- Product/order **ids are now strings** (Firestore ids). If your code assumes
  `number`, change those types (`productQty` keys become strings too).
- `canCancel` now lives in `data.ts` — import and use it.
- Customers screen: `const [customers,setCustomers]=useState([]); useEffect(()=>{ if(view==="admin-customers") data.listCustomers().then(setCustomers); },[view]);`
- Wrap each handler in `try { … } catch(e){ toast((e as Error).message); }` so
  rule rejections (e.g. cancel window closed) show to the user.

## 5. Run it
```
cd roti-and-more-app
npm install
npm run dev
```
Log in with your test numbers (see FIREBASE_SETUP.md). Once it works in the
browser, build the Android app — see `ANDROID_BUILD.md`.
