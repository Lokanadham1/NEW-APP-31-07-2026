# Handoff: Roti & More — App Screens

## Overview
Roti & More (CJ Lokesh Caterings) is a mobile catering-ordering app for a flatbread business serving India (₹ pricing, +91 mobile numbers). It has two roles resolved by mobile number at login: **customers** who browse a catalog and place orders, and **admins** who manage products, orders, payments, and customers. This bundle documents every screen so a developer can implement the app in a real codebase.

## About the Design Files
The file `Roti & More Screens.dc.html` in this bundle is a **design reference created in HTML** — a prototype showing the intended look, layout, and content of every screen. It is **not production code to copy directly**. It is a single canvas showing 13 phone mockups side by side.

The task is to **recreate these designs in the target codebase**. A React app already exists (`roti-and-more-app`, Vite + React + TypeScript + Tailwind, Capacitor for Android), plus a Firebase data layer (`src/firebase/`) and optional Node/Cloud-Functions backends. Implement the screens using the app's existing patterns (Tailwind theme tokens, Roboto, the `data.ts` Firestore layer). If recreating fresh, React + Tailwind + Firebase is the established stack.

## Fidelity
**High-fidelity (hifi).** The mockups carry final colors, typography, spacing, iconography, and content. Recreate the UI pixel-close using the codebase's existing libraries. Exact tokens are in the Design Tokens section.

## Screens / Views

All screens are 300×640 phone frames, Roboto throughout, cream background `#FFF8F5`, terracotta primary `#BF4800`. Bottom nav is fixed; content scrolls between a header and the nav.

**Customer nav:** Home · Orders · Alerts. **Admin nav:** Dashboard · Orders · Products · Customers · Alerts.

### 1. Login / Sign up
- **Purpose:** Single entry for everyone; the entered mobile number decides role.
- **Layout:** Top ~40% is a terracotta gradient header (logo tile 76px, title, tagline). Below on cream: "Login or Sign up" heading, a bordered `+91` mobile field, a full-width "Continue" pill button, an "OTP verification" divider, a 4-box OTP row, and a note that admin numbers auto-open the dashboard.
- **Components:** Logo tile `rgba(255,255,255,.2)` on gradient `linear-gradient(160deg,#BF4800,#7C2D00)`; mobile field 2px border `#BF4800`, bg `#FFF3EE`, floating label; OTP boxes 38×46, active box border `#BF4800`. Primary button bg `#BF4800`, white text, radius 24px.

### 2. Complete Profile
- **Purpose:** First-time customers after OTP verify.
- **Layout:** Back chevron + "Complete your profile" + "✓ +91 … verified". Three fields: Name*, Catering Business Name*, Address* (textarea). Blue info card. "Save & Start Ordering" button.
- **Components:** Fields as above (active field border `#BF4800`); info card bg `#eff6ff`, border `#dbeafe`, text `#1d4ed8`.

### 3. Home / Catalog (customer)
- **Purpose:** Browse products, adjust quantities, see running cart total.
- **Layout:** Header (greeting, search pill, category chips) → scrolling product cards → sticky orange cart bar → bottom nav (Home active).
- **Components:** Product card white, border `#E0CEC6`, radius 18px, 52px emoji thumb on `#F5DDD1`; name 13px/500, desc 10px `#7D5E50`, price 12px/700 `#BF4800`. Qty stepper: 26px circular `#BF4800`-outline buttons; unselected items show a filled `+` circle. Cart bar bg `#BF4800`, white text, "Review →" chip. Chips: selected bg `#BF4800`/white, else bg `#FFF8F5` border `#E0CEC6`.

### 4. Checkout
- **Purpose:** Pick delivery date + time slot, place order.
- **Layout:** Back + "Checkout" → calendar card → time-slot grid card → "Place Order · ₹total" button.
- **Components:** Calendar: month nav row, 7-col day grid, selected day filled `#BF4800` circle, past days `#cbb`, footer confirms the date in `#BF4800`. Time slots: 4-col grid, selected bg `#BF4800`/white, else `#E0CEC6` border.

### 5. My Orders (customer)
- **Purpose:** List the customer's orders with status.
- **Components:** Order card: `#id` 14px/700, status badge (see status colors), item summary line, and either a total row or a payment progress bar (`#22c55e` fill on `#EDE0D7` track) with Paid/Due split.

### 6. Order Detail (customer)
- **Purpose:** Full order view + actions.
- **Layout:** Header (#id, placed date) → Items card → Payment card (progress bar, Paid/Remaining) → blue Delivery Schedule card → tonal "Reschedule Delivery" button → nav.
- **Components:** Payment badge `Advance Paid` bg `#dbeafe` text `#1e40af`. Delivery card bg `#eff6ff` border `#dbeafe` text `#1d4ed8`. Tonal button bg `#F5DDD1` text `#3E1300`.

### 7. Alerts (customer)
- **Purpose:** Smart reminders + support contact + history.
- **Components:** Support card (42px `#BF4800` circle 📞, phone `#BF4800`). URGENT group: red card bg `#fef2f2` border `#fecaca`, count badge bg `#fee2e2` text `#b91c1c`. REMINDERS group: amber card bg `#fffbeb` border `#fde68a`.

### 8. Admin Dashboard
- **Purpose:** At-a-glance stats + pending queue.
- **Layout:** Header (Dashboard, logout icon) → 2×2 stat tiles → Revenue card → "Needs Acceptance" card with Accept/Reject → admin nav.
- **Components:** Stat tiles use tinted pairs — blue `#eff6ff/#dbeafe/#1d4ed8`, amber `#fffbeb/#fde68a/#b45309`, green `#f0fdf4/#bbf7d0/#15803d`, purple `#faf5ff/#e9d5ff/#7e22ce`; number 30px/700. Accept button primary; Reject outline `#BA1A1A`.

### 9. Admin Orders
- **Purpose:** Filter and manage all orders.
- **Layout:** Header + filter chips (All/Pending/Accepted/Completed) → order cards → nav.
- **Components:** Card shows customer name, phone, date, status badge, tinted item breakdown box, and action buttons per state (Accept/Reject, or Add Payment/Reschedule). Filter chips small (9.5px, padding 5×9) so all four fit one row.

### 10. Products (admin)
- **Purpose:** CRUD catalog.
- **Components:** Header with count + "＋ Add" pill. Row card: 48px emoji thumb, name, desc, price `#BF4800`, availability pill (Available `#dcfce7/#15803d`, Out of Stock `#fee2e2/#dc2626`), edit ✎ / delete 🗑 icons.

### 11. Customers (admin)
- **Purpose:** Searchable customer list with totals.
- **Components:** Search pill. Customer card: CUS-id pill `#F5DDD1/#BF4800`, name, phone, chevron; 3-col stat mini-cards Orders / Purchase / Pending (pending tinted orange `#fff7ed/#c2410c`, or green when ₹0).

### 12. Customer Profile (admin)
- **Purpose:** One customer's stats, orders, bills.
- **Layout:** Terracotta header (status bar + CUS-id + name + phone) → stats card → Orders/Bills tab toggle → filter chips → order cards with Add Payment.
- **Components:** Header bg `#BF4800` white text. Tab toggle: pill track `#EDE0D7`, active tab white with shadow.

### 13. Admin Alerts
- **Purpose:** Urgent items + reminders + activity log.
- **Components:** URGENT (red) and REMINDERS (amber) groups as in screen 7; ACTIVITY LOG card bg `rgba(191,72,0,.05)` border `rgba(191,72,0,.3)` with a "● New" marker in `#BF4800`.

## Interactions & Behavior
- **Auth routing:** after OTP verify, admin → Dashboard (skips profile); returning customer → Home; new customer → Complete Profile. Role from the `/admins/{+91phone}` allowlist.
- **Qty steppers** mutate a cart map; cart bar shows live item count + total.
- **Checkout:** time slot must be ≥2 hours ahead; date picker disables past days.
- **Order lifecycle:** pending → approved → completed; or rejected/cancelled.
- **Cancel:** allowed only while pending and within 6 hours of placement.
- **Reschedule:** customers once per order; admins any time.
- **Address edit:** once per order.
- **Payments:** record partial/full; cannot exceed balance; auto-completes at ₹0 balance; progress bar reflects paidAmount/total.
- **Notifications:** created on order events; customer sees own, admin sees broadcasts; mark-read / mark-all-read.
- **Bills:** printable via `window.print`.
- Buttons: subtle press feedback; status badges are non-interactive.

## State Management
- **Auth:** `{ ready, me, role }` from `AuthProvider` (Firebase phone auth). `me` = `{ uid, mobile, customerId, role, name, cateringName, address, profileDone }`.
- **App data:** `orders[]`, `products[]`, `notifications[]`, `customers[]` (admin). Loaded via `data.ts`; live via `live.ts` (`watchOrders/watchProducts/watchNotifications`).
- **Cart:** `productQty` map (client-only, may persist in localStorage).
- **UI:** current `view`/route, checkout date/time, active filters, modal/sheet open states, form field values.
- **Fetching:** Firestore reads for lists; writes via `data.ts` actions (or Cloud Functions on the Blaze path).

## Design Tokens
**Colors**
- Background `#FFF8F5`; surface `#FFFFFF`; card border `#E0CEC6`; input bg `#FFF3EE`; neutral track `#EDE0D7`; box tint `#f6eee7`.
- Primary `#BF4800`; primary-dark `#7C2D00`; secondary `#F5DDD1`; on-secondary `#3E1300`.
- Text: heading `#211200`; muted `#7D5E50`.
- Destructive `#BA1A1A` / `#dc2626`.
- Status — Pending amber `#fffbeb/#fde68a/#b45309`; Accepted/info blue `#eff6ff/#dbeafe/#1d4ed8`; Partial orange `#fff7ed/#fed7aa/#c2410c`; Delivered/success green `#f0fdf4/#bbf7d0/#15803d`; Urgent red `#fef2f2/#fecaca/#b91c1c`; purple `#faf5ff/#e9d5ff/#7e22ce`. Progress fill `#22c55e`.
**Typography** — Roboto 400/500/700. Sizes: page title 19px/500; stat number 30px/700; card title 13–14px; body 11–12px; captions 9–10px `#7D5E50`. Min body text 24px on 1080p, but this app targets phone px as listed.
**Spacing** — screen padding 16×18px; card padding 12–13px; content gap 14–15px; grid gaps 9–11px.
**Radius** — cards 16–18px; buttons/chips 20–24px (pill); inputs 4–8px; thumbs 14–16px; stat tiles 14px.
**Shadow** — cards `0 1px 3px rgba(33,18,0,.05)`; frame/floating `0 12px 24px rgba(0,0,0,.2)`.

## Assets
- **Icons/emoji:** the mockups use emoji as placeholders (🍽️ logo, 🫓 flatbreads, 🍡 snacks, status dots, nav glyphs). In production, replace with a real icon set (the app uses `lucide-react`) and real product photos (Firebase Storage `imageUrl`).
- **Fonts:** Roboto via Google Fonts.
- **Logo:** placeholder tile — supply the real CJ Lokesh Caterings logo.
- No licensed image assets are embedded.

## Files
- `Roti & More Screens.dc.html` — the design reference (all 13 screens on one canvas).
- Firebase data layer referenced by the design (already in the app): `src/firebase/config.ts`, `auth.tsx`, `data.ts`, `live.ts`; login screen `src/app/LoginFlow.tsx`; rules `firestore.rules`; data shapes `firestore-structure.md`; setup guides `FIREBASE_SETUP.md`, `APP_INTEGRATION.md`, `ANDROID_BUILD.md`, `FUNCTIONS_SETUP.md`.
