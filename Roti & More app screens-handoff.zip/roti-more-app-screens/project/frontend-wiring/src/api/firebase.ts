// src/api/firebase.ts — Firebase Phone Auth client setup.
// Fill the VITE_FB_* vars in .env from Firebase console → Project settings → Web app.
import { initializeApp } from "firebase/app";
import { getAuth, RecaptchaVerifier, signInWithPhoneNumber, ConfirmationResult } from "firebase/auth";

const cfg = {
  apiKey: import.meta.env.VITE_FB_API_KEY,
  authDomain: import.meta.env.VITE_FB_AUTH_DOMAIN,
  projectId: import.meta.env.VITE_FB_PROJECT_ID,
  appId: import.meta.env.VITE_FB_APP_ID,
};

export const fbApp = initializeApp(cfg);
export const fbAuth = getAuth(fbApp);

/**
 * Create an invisible reCAPTCHA bound to a DOM element id. Firebase requires
 * this before sending an SMS. Call once and reuse.
 */
export function makeRecaptcha(containerId: string) {
  return new RecaptchaVerifier(fbAuth, containerId, { size: "invisible" });
}

/** Send the OTP SMS to a 10-digit Indian number. Returns a confirmation handle. */
export function sendSms(mobile10: string, verifier: RecaptchaVerifier): Promise<ConfirmationResult> {
  return signInWithPhoneNumber(fbAuth, "+91" + mobile10, verifier);
}
