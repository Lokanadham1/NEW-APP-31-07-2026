// src/api/auth.tsx — auth state (token + role + profile) with role-based routing.
import { createContext, useContext, useEffect, useState, ReactNode } from "react";
import { api, getToken, setToken, Me, Role } from "./client";

type AuthState = {
  ready: boolean;            // finished restoring session on load
  me: Me | null;
  role: Role | null;
  isAuthed: boolean;
  onVerified: (token: string, user: Me) => void; // call after verify-otp
  refreshMe: () => Promise<void>;
  logout: () => void;
};

const Ctx = createContext<AuthState>(null as any);
export const useAuth = () => useContext(Ctx);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [me, setMe] = useState<Me | null>(null);
  const [ready, setReady] = useState(false);

  // Restore session: if a token exists, fetch /me. Invalid token clears it.
  useEffect(() => {
    (async () => {
      if (getToken()) {
        try { setMe(await api.me()); }
        catch { setToken(null); setMe(null); }
      }
      setReady(true);
    })();
  }, []);

  const onVerified = (token: string, user: Me) => { setToken(token); setMe(user); };
  const refreshMe = async () => setMe(await api.me());
  const logout = () => { setToken(null); setMe(null); };

  return (
    <Ctx.Provider value={{
      ready, me, role: me?.role ?? null, isAuthed: !!me,
      onVerified, refreshMe, logout,
    }}>
      {children}
    </Ctx.Provider>
  );
}

/**
 * Decide the landing view from auth state. Use in App to replace the old
 * splash/login-based initial `view`:
 *
 *   const { ready, me } = useAuth();
 *   if (!ready) return <Splash/>;              // brief boot screen
 *   if (!me) return <LoginFlow/>;              // not logged in
 *   if (me.role === "admin") view = "admin-dashboard";
 *   else if (!me.profileDone) view = "profile-setup";
 *   else view = "user-home";
 */
export function landingView(me: Me | null): string {
  if (!me) return "login";
  if (me.role === "admin") return "admin-dashboard";
  if (!me.profileDone) return "profile-setup";
  return "user-home";
}
