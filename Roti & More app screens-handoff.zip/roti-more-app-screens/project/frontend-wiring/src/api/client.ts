// src/api/client.ts — typed client for the Roti & More backend.
// All calls throw on non-2xx with the server's { error } message.

const BASE = import.meta.env.VITE_API_URL || "http://localhost:4000";
const TOKEN_KEY = "rm_token";

export const getToken = () => localStorage.getItem(TOKEN_KEY);
export const setToken = (t: string | null) =>
  t ? localStorage.setItem(TOKEN_KEY, t) : localStorage.removeItem(TOKEN_KEY);

async function req<T>(path: string, opts: RequestInit = {}): Promise<T> {
  const token = getToken();
  const res = await fetch(BASE + path, {
    ...opts,
    headers: {
      "Content-Type": "application/json",
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
      ...(opts.headers || {}),
    },
  });
  const body = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(body.error || `Request failed (${res.status})`);
  return body as T;
}

// ─── Types (mirror the app's) ────────────────────────────────────────────────
export type Role = "user" | "admin";
export type Product = { id: number; name: string; price: number; description: string; category: string; status: "available" | "out_of_stock"; imageUrl?: string };
export type OrderItem = { productId: number; name: string; price: number; quantity: number };
export type Payment = { amount: number; date: string; note: string; mode: "Cash" | "UPI" | "Bank Transfer"; transactionId: string };
export type Order = {
  id: number; userId: number; customerName: string; customerMobile: string; customerAddress: string;
  items: OrderItem[]; subtotal: number; gst: number; delivery: number; total: number;
  status: "pending" | "approved" | "completed" | "rejected" | "cancelled";
  createdDate: string; createdAt: string; deliveryDate: string | null; deliveryTime: string | null;
  remarks: string | null; contactPerson: string | null; paidAmount: number; payments: Payment[];
  addressEditUsed: boolean; rescheduleUsed: boolean;
};
export type Notification = { id: number; userId: number; message: string; read: boolean; createdDate: string };
export type Me = { id: number; mobile: string; customerId: string | null; role: Role; name?: string; cateringName?: string; address?: string; profileDone: boolean };
export type Customer = { userId: number; customerId: string; name: string; mobile: string; address: string; orderCount: number; totalPurchase: number; totalPaid: number; pending: number; orders: Order[] };

export const api = {
  // auth
  requestOtp: (mobile: string) => req<{ sent: boolean; devCode?: string }>("/auth/request-otp", { method: "POST", body: JSON.stringify({ mobile }) }),
  verifyOtp: (mobile: string, code: string) => req<{ token: string; role: Role; profileComplete: boolean; user: Me }>("/auth/verify-otp", { method: "POST", body: JSON.stringify({ mobile, code }) }),
  // firebase phone auth — exchange a verified Firebase ID token for our JWT
  firebaseLogin: (idToken: string) => req<{ token: string; role: Role; profileComplete: boolean; user: Me }>("/auth/firebase", { method: "POST", body: JSON.stringify({ idToken }) }),

  // profile
  me: () => req<Me>("/me"),
  saveProfile: (p: { name: string; cateringName?: string; address: string }) => req<Me>("/me/profile", { method: "PUT", body: JSON.stringify(p) }),

  // products
  listProducts: () => req<Product[]>("/products"),
  createProduct: (p: Partial<Product>) => req<Product>("/products", { method: "POST", body: JSON.stringify(p) }),
  updateProduct: (id: number, p: Partial<Product>) => req<Product>(`/products/${id}`, { method: "PUT", body: JSON.stringify(p) }),
  deleteProduct: (id: number) => req<{ ok: true }>(`/products/${id}`, { method: "DELETE" }),

  // orders
  listOrders: (status?: string) => req<Order[]>(`/orders${status && status !== "all" ? `?status=${status}` : ""}`),
  getOrder: (id: number) => req<Order>(`/orders/${id}`),
  createOrder: (o: { items: { productId: number; quantity: number }[]; deliveryDate: string; deliveryTime: string; remarks?: string }) => req<Order>("/orders", { method: "POST", body: JSON.stringify(o) }),
  acceptOrder: (id: number) => req<Order>(`/orders/${id}/accept`, { method: "POST" }),
  rejectOrder: (id: number) => req<Order>(`/orders/${id}/reject`, { method: "POST" }),
  deliverOrder: (id: number) => req<Order>(`/orders/${id}/deliver`, { method: "POST" }),
  cancelOrder: (id: number) => req<Order>(`/orders/${id}/cancel`, { method: "POST" }),
  reschedule: (id: number, deliveryDate: string, deliveryTime: string) => req<Order>(`/orders/${id}/reschedule`, { method: "POST", body: JSON.stringify({ deliveryDate, deliveryTime }) }),
  editAddress: (id: number, address: string) => req<Order>(`/orders/${id}/address`, { method: "PUT", body: JSON.stringify({ address }) }),
  addPayment: (id: number, p: { amount: number; note?: string; mode?: string; transactionId?: string }) => req<Order>(`/orders/${id}/payments`, { method: "POST", body: JSON.stringify(p) }),
  bill: (id: number) => req<any>(`/orders/${id}/bill`),

  // customers (admin)
  listCustomers: (q?: string) => req<Customer[]>(`/customers${q ? `?q=${encodeURIComponent(q)}` : ""}`),
  getCustomer: (mobile: string) => req<Customer>(`/customers/${mobile}`),

  // notifications
  listNotifications: () => req<Notification[]>("/notifications"),
  markRead: (id: number) => req<{ ok: true }>(`/notifications/${id}/read`, { method: "POST" }),
  markAllRead: () => req<{ ok: true }>("/notifications/read-all", { method: "POST" }),
};
