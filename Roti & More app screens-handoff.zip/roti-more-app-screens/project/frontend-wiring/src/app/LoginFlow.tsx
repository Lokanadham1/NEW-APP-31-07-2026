// src/app/LoginFlow.tsx — OTP login/signup + profile setup.
// Replaces the old splash "Order Now / Admin Panel" screen and both logins.
// Role is decided by the backend allowlist and returned in the token — this
// component just routes on it.
import { useState } from "react";
import { toast } from "sonner";
import { ChevronLeft } from "lucide-react";
import { api, Me } from "../api/client";
import { useAuth } from "../api/auth";

type Step = "mobile" | "otp" | "profile";

export default function LoginFlow({ onDone }: { onDone: (me: Me) => void }) {
  const { onVerified, refreshMe } = useAuth();
  const [step, setStep] = useState<Step>("mobile");
  const [mobile, setMobile] = useState("");
  const [code, setCode] = useState("");
  const [devCode, setDevCode] = useState<string | null>(null);
  const [name, setName] = useState("");
  const [catering, setCatering] = useState("");
  const [address, setAddress] = useState("");
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);

  const requestOtp = async () => {
    if (mobile.length !== 10) return setErr("Enter a valid 10-digit mobile number.");
    setErr(""); setBusy(true);
    try {
      const r = await api.requestOtp(mobile);
      setDevCode(r.devCode ?? null);          // shown only in dev mode
      if (r.devCode) toast(`Dev OTP: ${r.devCode}`);
      setStep("otp");
    } catch (e: any) { setErr(e.message); } finally { setBusy(false); }
  };

  const verify = async () => {
    if (code.length < 4) return setErr("Enter the 4-digit code.");
    setErr(""); setBusy(true);
    try {
      const r = await api.verifyOtp(mobile, code);
      onVerified(r.token, r.user);
      if (r.role === "admin" || r.profileComplete) onDone(r.user);
      else setStep("profile");                 // new customer → collect details
    } catch (e: any) { setErr(e.message); } finally { setBusy(false); }
  };

  const saveProfile = async () => {
    if (!name.trim()) return setErr("Please enter your name.");
    if (!address.trim()) return setErr("Please enter your address.");
    setErr(""); setBusy(true);
    try {
      const me = await api.saveProfile({ name, cateringName: catering, address });
      await refreshMe();
      onDone(me);
    } catch (e: any) { setErr(e.message); } finally { setBusy(false); }
  };

  const Err = () => err ? <p className="text-destructive text-sm">{err}</p> : null;
  const field = "w-full border-2 border-border rounded-[4px] px-4 py-3 bg-input-background text-sm outline-none focus:border-primary";

  return (
    <div className="min-h-screen bg-background flex flex-col" style={{ fontFamily: "Roboto, sans-serif" }}>
      {/* brand header */}
      <div className="px-6 pt-14 pb-8 flex flex-col items-center gap-3"
        style={{ background: "linear-gradient(160deg,#BF4800 0%,#7C2D00 100%)" }}>
        <div className="w-20 h-20 bg-white/20 rounded-3xl flex items-center justify-center text-4xl">🍽️</div>
        <h1 className="text-2xl font-bold text-white">Roti &amp; More</h1>
        <p className="text-white/80 text-xs">Fresh flatbreads, delivered</p>
      </div>

      <div className="flex-1 px-6 pt-6 space-y-4">
        {step === "mobile" && (
          <>
            <div>
              <h2 className="text-xl font-medium text-foreground">Login or Sign up</h2>
              <p className="text-sm text-muted-foreground mt-1">Enter your mobile number to continue</p>
            </div>
            <div className="flex items-center border-2 border-primary rounded-lg px-3 bg-input-background">
              <span className="text-sm font-medium pr-2 border-r border-border">🇮🇳 +91</span>
              <input value={mobile} maxLength={10} inputMode="numeric"
                onChange={(e) => setMobile(e.target.value.replace(/\D/g, ""))}
                placeholder="Mobile number"
                className="flex-1 py-3 pl-3 bg-transparent text-sm outline-none" />
            </div>
            <Err />
            <button disabled={busy} onClick={requestOtp}
              className="w-full bg-primary text-white py-3 rounded-full text-sm font-medium disabled:opacity-50">
              {busy ? "Sending…" : "Continue"}
            </button>
            <p className="text-xs text-muted-foreground text-center">Admin numbers open the Admin dashboard automatically.</p>
          </>
        )}

        {step === "otp" && (
          <>
            <button onClick={() => setStep("mobile")} className="flex items-center gap-1 text-sm text-muted-foreground">
              <ChevronLeft size={16} /> Change number
            </button>
            <div>
              <h2 className="text-xl font-medium text-foreground">Verify number</h2>
              <p className="text-sm text-muted-foreground mt-1">Code sent to +91 {mobile}</p>
            </div>
            {devCode && <p className="text-xs bg-secondary text-primary rounded-lg px-3 py-2">Dev mode code: <b>{devCode}</b></p>}
            <input value={code} maxLength={6} inputMode="numeric"
              onChange={(e) => setCode(e.target.value.replace(/\D/g, ""))}
              placeholder="Enter OTP" className={`${field} tracking-[0.5em] text-center text-lg`} />
            <Err />
            <button disabled={busy} onClick={verify}
              className="w-full bg-primary text-white py-3 rounded-full text-sm font-medium disabled:opacity-50">
              {busy ? "Verifying…" : "Verify & Continue"}
            </button>
            <button onClick={requestOtp} className="w-full text-primary text-sm font-medium">Resend code</button>
          </>
        )}

        {step === "profile" && (
          <>
            <div>
              <h2 className="text-xl font-medium text-foreground">Complete your profile</h2>
              <p className="text-xs text-muted-foreground mt-1">✓ +91 {mobile} verified</p>
            </div>
            <input value={name} onChange={(e) => setName(e.target.value)} placeholder="Name *" className={field} />
            <input value={catering} onChange={(e) => setCatering(e.target.value)} placeholder="Catering Business Name" className={field} />
            <textarea value={address} onChange={(e) => setAddress(e.target.value)} placeholder="Address *" rows={3} className={`${field} resize-none`} />
            <Err />
            <button disabled={busy} onClick={saveProfile}
              className="w-full bg-primary text-white py-3 rounded-full text-sm font-medium disabled:opacity-50">
              {busy ? "Saving…" : "Save & Start Ordering"}
            </button>
          </>
        )}
      </div>
    </div>
  );
}
