# Wiring the app to the backend (Option 2)

Drop-in files that replace the `localStorage` data layer and the old
splash/admin-login with real OTP auth + role routing. Copy them into your app,
then apply the edits below to `App.tsx`.

## 0. Files to copy
```
frontend-wiring/src/api/client.ts   ->  roti-and-more-app/src/api/client.ts
frontend-wiring/src/api/auth.tsx    ->  roti-and-more-app/src/api/auth.tsx
frontend-wiring/src/app/LoginFlow.tsx -> roti-and-more-app/src/app/LoginFlow.tsx
```
Add to `roti-and-more-app/.env` (Vite):
```
VITE_API_URL=http://localhost:4000
```
Start the backend (`cd backend && npm start`) before running the app.

## 1. Wrap the app with AuthProvider
In `src/main.tsx`:
```tsx
import { AuthProvider } from "./api/auth";
// ...
root.render(<AuthProvider><App /></AuthProvider>);
```

## 2. Boot: gate on auth instead of localStorage
At the top of `App()` remove the `ls(...)`-based initial state for
`currentUser` / `isAdmin` / `view`, and instead read auth + load server data:

```tsx
import { useAuth, landingView } from "../api/auth";
import { api } from "../api/client";
import LoginFlow from "./LoginFlow";

const { ready, me, logout: authLogout } = useAuth();
const [view, setView] = useState("splash");
const [orders, setOrders] = useState<Order[]>([]);
const [products, setProducts] = useState<Product[]>([]);
const [notifications, setNotifications] = useState<Notification[]>([]);

// route + load once auth is known
useEffect(() => {
  if (!ready) return;
  setView(landingView(me));
  if (me) reload();
}, [ready, me]);

async function reload() {
  const [o, p, n] = await Promise.all([
    api.listOrders(), api.listProducts(), api.listNotifications(),
  ]);
  setOrders(o); setProducts(p); setNotifications(n);
}
```

Delete every `useEffect` that persists state to `localStorage`
(`LS_ORDERS`, `LS_NOTIFS`, `LS_CART` may stay for the cart, etc.) and the
`ls()` seed defaults — the server is now the source of truth.

## 3. Render the login flow
Right before the existing view switch:
```tsx
if (!ready) return <SplashBoot/>;           // any simple branded screen
if (!me) return <LoginFlow onDone={() => { setView(landingView(me)); reload(); }} />;
```
You can now **delete** the old `splash`, `user-login`, and `admin-login`
views and their handlers: `submitUserLogin`, `submitAdminLogin`, and the
`loginName/loginPhone/adminUser/adminPass` state.

## 4. Swap each handler for its API call
Replace the body of each handler; keep the `toast`/UI parts. After a
successful call, either update local state from the returned order or call
`reload()`.

| Old handler | New |
|---|---|
| `placeOrder` | `const o = await api.createOrder({ items: selectedItems.map(p=>({productId:p.id, quantity:productQty[p.id]})), deliveryDate: checkoutDate, deliveryTime: checkoutTime, remarks: checkoutNotes }); setOrders(prev=>[o,...prev]); setProductQty({}); setView("user-orders");` |
| `cancelOrder(id)` | `const o = await api.cancelOrder(id); setOrders(prev=>prev.map(x=>x.id===id?o:x));` |
| `userReschedule` | `const o = await api.reschedule(userRescheduleOrder.id, userRescheduleDate, userRescheduleTime); setOrders(prev=>prev.map(x=>x.id===o.id?o:x));` |
| `submitAddressEdit` | `const o = await api.editAddress(addressEditOrder.id, addressEditValue); setOrders(prev=>prev.map(x=>x.id===o.id?o:x));` |
| `addPayment` | `const o = await api.addPayment(paymentOrder.id, { amount:Number(paymentAmount), note:paymentNote, mode:paymentMode, transactionId:paymentTxId }); setOrders(prev=>prev.map(x=>x.id===o.id?o:x));` |
| `confirmAccept` | `const o = await api.acceptOrder(acceptOrder.id); setOrders(prev=>prev.map(x=>x.id===o.id?o:x));` |
| Reject button | `const o = await api.rejectOrder(order.id); setOrders(prev=>prev.map(x=>x.id===o.id?o:x));` |
| Mark delivered | `const o = await api.deliverOrder(order.id); setOrders(prev=>prev.map(x=>x.id===o.id?o:x));` |
| `adminReschedule` | `const o = await api.reschedule(deliveryUpdateOrder.id, newDeliveryDate, newDeliveryTime); setOrders(prev=>prev.map(x=>x.id===o.id?o:x));` |
| `saveProduct` | create: `const p = await api.createProduct({...}); setProducts(prev=>[...prev,p]);` · edit: `const p = await api.updateProduct(editingProduct.id, {...}); setProducts(prev=>prev.map(x=>x.id===p.id?p:x));` |
| `deleteProduct(id)` | `await api.deleteProduct(id); setProducts(prev=>prev.filter(p=>p.id!==id));` |
| `markNotifRead(id)` | `await api.markRead(id); setNotifications(prev=>prev.map(n=>n.id===id?{...n,read:true}:n));` |
| "Mark all read" | `await api.markAllRead(); setNotifications(prev=>prev.map(n=>({...n,read:true})));` |
| `logout` | `authLogout(); setView("login"); setProductQty({});` |

Wrap each in `try/catch` and `toast(e.message)` on failure (the server
enforces the 6-hour cancel window, once-only reschedule/address, payment
limits, etc., so surface those messages).

## 5. Customers screen
Replace the client-side `customerList` derivation with:
```tsx
const [customers, setCustomers] = useState<Customer[]>([]);
useEffect(() => { if (view==="admin-customers") api.listCustomers(customerSearch).then(setCustomers); }, [view, customerSearch]);
```
and render `customers` instead of the computed list. For the profile screen,
`api.getCustomer(mobile)`.

## 6. Notes
- **`pushNotif`**: the server now creates notification records. Keep a local
  `toast(msg)` for instant UX, but drop the `setNotifications(... id: prev.length+1 ...)`
  line — call `reload()` (or re-fetch notifications) to pull the server copy.
- **Polling**: to see the other role's actions live, poll `reload()` every
  ~15s while logged in, or add websockets later.
- **Customer IDs / order IDs** are now assigned by the server; remove
  `customerIdCounter`, `INITIAL_CUST_IDS`, and the random-id logic.
- The **cart** (`productQty`) can stay in `localStorage` — it's client-only UI state.

## 7. Verify end-to-end
1. `cd backend && npm run seed && npm start`
2. `cd roti-and-more-app && npm run dev`
3. Log in with `9876543210` (customer, dev OTP shown in a toast / console).
4. Log in with `7730001663` (admin — `ADMIN_MOBILES`) → lands on dashboard.
5. Place an order as the customer; accept + record payment as admin; confirm
   the customer sees the status/notification after a reload.
