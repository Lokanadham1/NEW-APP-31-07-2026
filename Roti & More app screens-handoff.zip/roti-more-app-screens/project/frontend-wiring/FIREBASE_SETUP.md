# Option 3 — Firebase Phone Auth (real SMS OTP)

Firebase generates, sends, and verifies the OTP on the client; the backend then
verifies Firebase's ID token and issues your own JWT (with the same admin
allowlist). Free at low volume, no SMS code to maintain.

## A. Firebase console setup
1. Create a project → add a **Web app** → copy the config (apiKey, authDomain,
   projectId, appId).
2. **Build → Authentication → Sign-in method → Phone → Enable.**
3. Add your dev domain (`localhost`) under **Authentication → Settings →
   Authorized domains**.
4. (Optional) **Phone numbers for testing** — add `+919876543210` with code
   `123456` so you can test without spending SMS.
5. **Project settings → Service accounts → Generate new private key** →
   download the JSON. This is for the backend.

## B. Backend
Already wired in this bundle:
- `backend/firebase.js` — verifies ID tokens via `firebase-admin`.
- `POST /auth/firebase { idToken }` in `server.js` — maps the phone to a user,
  applies the allowlist, returns your JWT.

Steps:
```bash
cd backend
npm install            # now pulls firebase-admin
```
Add to `backend/.env`:
```
OTP_PROVIDER=firebase
FIREBASE_SERVICE_ACCOUNT=/absolute/path/to/serviceAccountKey.json
```
`npm start`.

## C. Frontend
```bash
cd roti-and-more-app
npm install firebase
```
Copy:
```
frontend-wiring/src/api/firebase.ts          -> src/api/firebase.ts
frontend-wiring/src/app/LoginFlow.firebase.tsx -> src/app/LoginFlow.firebase.tsx
```
Add to `roti-and-more-app/.env`:
```
VITE_API_URL=http://localhost:4000
VITE_FB_API_KEY=...
VITE_FB_AUTH_DOMAIN=your-project.firebaseapp.com
VITE_FB_PROJECT_ID=your-project
VITE_FB_APP_ID=...
```
In `App.tsx`, swap the import from Option 2:
```tsx
// import LoginFlow from "./LoginFlow";
import LoginFlow from "./LoginFlow.firebase";
```
Everything else (AuthProvider, routing, the `onDone` callback, all data
handlers) is unchanged — `firebaseLogin()` returns the same
`{ token, role, profileComplete, user }` shape as `verifyOtp()`.

## D. Flow recap
1. User enters mobile → invisible reCAPTCHA → Firebase sends SMS.
2. User enters the 6-digit code → `confirmationResult.confirm(code)` verifies it
   with Firebase → we get a Firebase **ID token**.
3. Client POSTs the ID token to `/auth/firebase`.
4. Backend verifies it, checks `ADMIN_MOBILES`, and returns your app JWT.
5. Routing is identical to Option 2 (admin → dashboard, new user → profile, else
   home).

## Notes & gotchas
- **reCAPTCHA:** the component renders `<div id="recaptcha-root"/>` and uses the
  invisible size — no visible widget unless Firebase challenges a suspicious
  request.
- **Test numbers** (step A4) skip real SMS and reCAPTCHA — ideal for dev/demo.
- **Cost:** Phone Auth has a free daily verification quota; enable Blaze
  (pay-as-you-go) for production, but low volume typically stays free.
- **Keep dev mode too:** if you don't set `OTP_PROVIDER`, the Option-2
  `/auth/request-otp` + `/auth/verify-otp` dev flow still works — handy for
  local testing without Firebase.
